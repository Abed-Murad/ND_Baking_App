package com.am.nd_baking_app.util;

public class Listeners {
    public interface OnItemClickListener {
        void onItemClick(int position);
    }
}
