package com.am.nd_baking_app.util;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;
@GlideModule
public class GlideAppModule extends AppGlideModule {
}
